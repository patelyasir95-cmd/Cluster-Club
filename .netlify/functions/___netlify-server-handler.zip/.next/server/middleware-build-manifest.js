globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/k4yveXTAMrGxAC7R5XJBd/_buildManifest.js",
    "static/k4yveXTAMrGxAC7R5XJBd/_ssgManifest.js",
    "static/k4yveXTAMrGxAC7R5XJBd/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/045g~0~zva_mv.js",
    "static/chunks/0dgq26a5_oy.a.js",
    "static/chunks/0yoi6g0rt32bk.js",
    "static/chunks/0257pdz1-imal.js",
    "static/chunks/turbopack-0t3a3dp283dly.js"
  ]
};
